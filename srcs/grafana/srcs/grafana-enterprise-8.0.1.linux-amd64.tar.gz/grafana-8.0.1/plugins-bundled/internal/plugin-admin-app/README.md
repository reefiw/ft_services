# Grafana admin app

The grafana catalog is enabled or disabled by setting `plugin_admin_enabled` in the setup files.
